package com.basic.movierecommendation.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun DetailScreen(movieId: Int, viewModel: MovieViewModel, navController: NavController) {
    val movies by viewModel.movies.collectAsState()
    val movie = movies.find { it.id == movieId }

    movie?.let {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(text = it.title, style = MaterialTheme.typography.h4)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = it.description)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Genre: ${it.genre}")
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Rating: ${it.rating}")

            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = { viewModel.toggleFavorite(it.id) }) {
                Text(text = if (it.isFavorite) "Unfavorite" else "Favorite")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(text = "Your Rating:")
            var userRating by remember { mutableStateOf(it.userRating ?: 0f) }
            Slider(
                value = userRating,
                onValueChange = { userRating = it },
                valueRange = 0f..10f,
                steps = 9,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { viewModel.updateRating(it.id, userRating) }) {
                Text(text = "Submit Rating")
            }
        }
    }
}
