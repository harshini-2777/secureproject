package com.basic.movierecommendation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.basic.movierecommendation.ui.DetailScreen
import com.basic.movierecommendation.ui.HomeScreen
import com.basic.movierecommendation.ui.MovieViewModel
import com.basic.movierecommendation.ui.Screen
import com.basic.movierecommendation.ui.theme.MovieRecommendationAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MovieRecommendationAppTheme {
                val navController = rememberNavController()
                val viewModel: MovieViewModel = viewModel()

                Surface(color = MaterialTheme.colors.background) {
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route
                    ) {
                        composable(Screen.Home.route) {
                            HomeScreen(viewModel, navController)
                        }
                        composable(Screen.Detail.route) { backStackEntry ->
                            val movieId = backStackEntry.arguments?.getString("movieId")?.toInt() ?: 0
                            DetailScreen(movieId, viewModel, navController)
                        }
                    }
                }
            }
        }
    }
}
