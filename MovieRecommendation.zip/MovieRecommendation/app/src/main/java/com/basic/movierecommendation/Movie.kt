package com.basic.movierecommendation
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "movies")
data class Movie(
    @PrimaryKey val id: Int,
    val title: String,
    val description: String,
    val genre: String,
    val rating: Float,
    val isFavorite: Boolean = false,
    val userRating: Float? = null
)

