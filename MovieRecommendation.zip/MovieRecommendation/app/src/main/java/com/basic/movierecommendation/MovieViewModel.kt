package com.basic.movierecommendation.ui
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import com.basic.movierecommendation.Movie
import com.basic.movierecommendation.database.MovieDatabase

class MovieViewModel(application: Application) : AndroidViewModel(application) {
    private val db = MovieDatabase.getDatabase(application)
    private val movieDao = db.movieDao()

    private val _movies = MutableStateFlow<List<Movie>>(emptyList())
    val movies: StateFlow<List<Movie>> = _movies

    init {
        viewModelScope.launch {
            movieDao.getAllMovies().collect { movieList ->
                if (movieList.isEmpty()) {
                    movieDao.insertAll(sampleMovies)
                }
                _movies.value = movieList
            }
        }
    }

    fun toggleFavorite(movieId: Int) {
        viewModelScope.launch {
            val movie = movieDao.getMovieById(movieId)
            val updated = movie.copy(isFavorite = !movie.isFavorite)
            movieDao.updateMovie(updated)
        }
    }

    fun updateRating(movieId: Int, rating: Float) {
        viewModelScope.launch {
            val movie = movieDao.getMovieById(movieId)
            val updated = movie.copy(userRating = rating)
            movieDao.updateMovie(updated)
        }
    }

    fun searchMovies(query: String) {
        viewModelScope.launch {
            if (query.isEmpty()) {
                movieDao.getAllMovies().collect { _movies.value = it }
            } else {
                movieDao.getAllMovies().collect { list ->
                    _movies.value = list.filter { it.title.contains(query, ignoreCase = true) }
                }
            }
        }
    }
}

// Sample Movies
val sampleMovies = listOf(
    Movie(1, "Inception", "A mind-bending thriller", "Sci-Fi", 8.8f),
    Movie(2, "The Dark Knight", "Batman vs Joker", "Action", 9.0f),
    Movie(3, "Interstellar", "Space journey to save humanity", "Sci-Fi", 8.6f)
)
